// Background Service Worker - AItest Pro (Chain of Thought + Smart Answer Extractor + Slow Internet Adaptive)

const PROMPT_TEXT = `Fizika, matematika va ingliz tili ekspertisan.
Ushbu rasmda berilgan savolni mustaqil, qadamma-qadam, qisqa formulalar bilan tahlil qilib yech.

ENG MUHIM TALAB:
Yechim oxirida, eng so'nggi alohida qatorda FAQAT quyidagi formatda yakuniy variantni yoz:
JAVOB: A

(Variantlar: A, B, C yoki D. Agar to'g'ri variant bo'lmasa, JAVOB: [ozing ishlagan javoni qisqa qilib yoz ohirgi javobni])`;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action !== "capture") return;

    (async () => {
        try {
            const dataUrl = await new Promise((resolve, reject) => {
                chrome.tabs.captureVisibleTab(
                    null,
                    { format: "png" },
                    (url) => {
                        if (chrome.runtime.lastError || !url) {
                            reject(new Error(
                                chrome.runtime.lastError?.message ||
                                "Screenshot olib bo‘lmadi"
                            ));
                        } else {
                            resolve(url);
                        }
                    }
                );
            });

            const answer = await askGeminiWeb(dataUrl);
            sendResponse({ answer });
        } catch (error) {
            console.error("Screenshot/Gemini xatosi:", error);
            sendResponse({
                answer: "Xatolik: " + error.message
            });
        }
    })();

    return true;
});

async function getOrCreateGeminiTab() {
    const tabs = await chrome.tabs.query({
        url: "*://gemini.google.com/*"
    });

    if (tabs.length) return tabs[0];

    const tab = await chrome.tabs.create({
        url: "https://gemini.google.com/app",
        active: false
    });

    await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
            chrome.tabs.onUpdated.removeListener(listener);
            reject(new Error("Gemini sahifasi yuklanmadi."));
        }, 45000); // 45 soniya zaxira

        function listener(tabId, info) {
            if (tabId === tab.id && info.status === "complete") {
                clearTimeout(timeout);
                chrome.tabs.onUpdated.removeListener(listener);
                resolve();
            }
        }

        chrome.tabs.onUpdated.addListener(listener);
    });

    await new Promise(resolve => setTimeout(resolve, 2000));
    return tab;
}

// Orqa fonda muzlashdan saqlash (Unfreezer)
function unfreezeBackgroundTab() {
    try {
        Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
        Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });
        Object.defineProperty(Document.prototype, 'visibilityState', { get: () => 'visible', configurable: true });
        Object.defineProperty(Document.prototype, 'hidden', { get: () => false, configurable: true });
        document.hasFocus = () => true;

        window.requestAnimationFrame = function(callback) {
            return setTimeout(() => callback(performance.now()), 16);
        };
        window.cancelAnimationFrame = function(id) {
            clearTimeout(id);
        };

        window.dispatchEvent(new Event('focus'));
        document.dispatchEvent(new Event('visibilitychange'));
    } catch(e) {}
}

async function askGeminiWeb(dataUrl) {
    const tab = await getOrCreateGeminiTab();

    try {
        await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            world: "MAIN",
            func: unfreezeBackgroundTab
        });
    } catch(e) {}

    const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: attachImageAndAsk,
        args: [dataUrl, PROMPT_TEXT]
    });

    return results?.[0]?.result || "Gemini'dan javob olinmadi.";
}

// Gemini sahifasida bajariladigan asosiy funksiya
async function attachImageAndAsk(dataUrl, prompt) {
    try {
        try {
            Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
            Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });
            document.hasFocus = () => true;
        } catch(e) {}

        // 1. Eski javoblarni tamg'alab chiqish (adashmaslik uchun)
        document.querySelectorAll("model-response, message-content, .model-response-text")
            .forEach(el => el.setAttribute("data-aitest-old", "true"));

        const response = await fetch(dataUrl);
        const blob = await response.blob();
        const file = new File([blob], "screen.png", {
            type: "image/png"
        });

        const inputField =
            document.querySelector('rich-textarea [contenteditable="true"]') ||
            document.querySelector('[role="textbox"]') ||
            document.querySelector("textarea");

        if (!inputField) {
            return "Gemini chat maydoni topilmadi. Hisobingizga kirganingizni tekshiring.";
        }

        const inputContainer = inputField.closest('.input-area-container, .input-area, .bottom-container') ||
                               inputField.parentElement?.parentElement ||
                               document.body;

        // 2. Fayl inputini topish va rasmni biriktirish
        let fileInput = [...document.querySelectorAll('input[type="file"]')]
            .find(el => !el.disabled);

        if (!fileInput) {
            const buttons = [...inputContainer.querySelectorAll("button")];
            const uploadButton = buttons.find(button => {
                const label = [
                    button.getAttribute("aria-label"),
                    button.getAttribute("title"),
                    button.innerText
                ].filter(Boolean).join(" ").toLowerCase();

                if (/more|options|feedback|fikr|отзыв/i.test(label)) return false;

                return /attach|upload|file|fayl|biriktir|rasm|add/i.test(label);
            });

            uploadButton?.click();
            await new Promise(resolve => setTimeout(resolve, 500));

            fileInput = [...document.querySelectorAll('input[type="file"]')]
                .find(el => !el.disabled);
        }

        if (!fileInput) {
            return "Gemini fayl yuklash maydoni topilmadi.";
        }

        const transfer = new DataTransfer();
        transfer.items.add(file);

        fileInput.files = transfer.files;
        fileInput.dispatchEvent(new Event("input", { bubbles: true }));
        fileInput.dispatchEvent(new Event("change", { bubbles: true }));

        // 3. Promptni kiritish
        inputField.focus();
        try {
            document.execCommand("insertText", false, prompt);
        } catch(e) {}

        if (!inputField.textContent.includes("JAVOB:")) {
            let p = inputField.querySelector('p');
            if (!p) {
                p = document.createElement('p');
                inputField.appendChild(p);
            }
            p.textContent = prompt;
            inputField.dispatchEvent(new InputEvent("input", {
                bubbles: true,
                composed: true,
                inputType: "insertText",
                data: prompt
            }));
        }

        // 4. Rasm to'liq yuklangach Send tugmasini qidirish (Sekin internet uchun 15 soniyagacha sabr qiladi)
        let sendButton = null;
        for (let i = 0; i < 50; i++) { // 50 * 300ms = 15 soniya maksimal zaxira
            await new Promise(resolve => setTimeout(resolve, 300));

            const buttons = [...inputContainer.querySelectorAll("button")];
            const btn = buttons.find(button => {
                const label = [
                    button.getAttribute("aria-label"),
                    button.getAttribute("data-tooltip"),
                    button.getAttribute("title"),
                    button.innerText
                ].filter(Boolean).join(" ").toLowerCase();

                if (/feedback|отзыв|fikr|more|options|qo‘shimcha/i.test(label)) {
                    return false;
                }

                return /send message|xabarni yuborish|отправить сообщение|send-button/i.test(label) ||
                       (label.includes('send') && !label.includes('feedback')) ||
                       (label.includes('yuborish') && !label.includes('fikr')) ||
                       (label.includes('отправить') && !label.includes('отзыв')) ||
                       button.classList.contains('send-button');
            });

            // Rasm serverga yetib borgach Send tugmasi aktiv bo'lishi bilan loop to'xtaydi
            if (btn && !btn.disabled && btn.getAttribute("aria-disabled") !== "true") {
                sendButton = btn;
                break;
            }
        }

        // 5. Yuborish tugmasini bosish
        if (sendButton) {
            sendButton.click();
        } else {
            inputField.dispatchEvent(new KeyboardEvent("keydown", {
                key: "Enter",
                code: "Enter",
                keyCode: 13,
                which: 13,
                bubbles: true,
                cancelable: true,
                composed: true
            }));
        }

        // ================= FAQAT HARFNI AJRATIB OLISH (SMART PARSER) =================
        function extractCleanAnswer(rawText) {
            if (!rawText) return "Javob yo'q";

            const clean = rawText.replace(/[*_`#]/g, "").trim();

            const strictMatch = clean.match(/(?:JAVOB|ANSWER|ОТВЕТ)\s*[:=\-—]\s*([A-DА-Я0-9\-\+\.\,\?]+(?:\s*\([A-D]\))?)/i);
            if (strictMatch) {
                const ans = strictMatch[1].trim();
                const letterOnly = ans.match(/^([A-DА-Яa-dа-я]\??)/);
                if (letterOnly) return normalizeLetter(letterOnly[1]);
                return ans.slice(0, 5).trim();
            }

            const altMatch = clean.match(/(?:to['‘`]?g['‘`]?ri\s+javob|правильный\s+ответ|variant|to['‘`]?g['‘`]?ri\s+variant)\s*[:=\-—]?\s*(?:variant\s*)?([A-DА-Яa-dа-я0-9\?]+)/i);
            if (altMatch) {
                return normalizeLetter(altMatch[1]);
            }

            const lines = clean.split("\n").map(l => l.trim()).filter(Boolean);
            for (let i = lines.length - 1; i >= Math.max(0, lines.length - 6); i--) {
                const line = lines[i];

                const lineMatch = line.match(/(?:javob|answer|ответ|variant)?\s*[:=\-—]?\s*\b([A-DА-Яa-dа-я]\??)\b/i);
                if (lineMatch && lineMatch[1]) {
                    return normalizeLetter(lineMatch[1]);
                }

                const singleLetter = line.match(/^([A-DА-Яa-dа-я]\??)(?:\)|\.)?$/i);
                if (singleLetter) {
                    return normalizeLetter(singleLetter[1]);
                }
            }

            const allLetters = [...clean.matchAll(/\b([A-D]\??)\b/gi)];
            if (allLetters.length > 0) {
                return allLetters[allLetters.length - 1][1].toUpperCase();
            }

            const lastLine = lines[lines.length - 1] || "";
            return lastLine.slice(0, 10).trim();
        }

        function normalizeLetter(ch) {
            if (!ch) return "";
            let upper = ch.toUpperCase();
            if (upper.startsWith("А")) return "A" + upper.slice(1);
            if (upper.startsWith("В")) return "B" + upper.slice(1);
            if (upper.startsWith("С")) return "C" + upper.slice(1);
            if (upper.startsWith("Д")) return "D" + upper.slice(1);
            return upper;
        }

        // 6. Yangi javobni kutish (Sekin internet uchun 45-50 soniyagacha zaxira)
        return await new Promise(resolve => {
            let attempts = 0;
            let previousText = "";
            let stable = 0;

            const timer = setInterval(() => {
                attempts++;

                const newModelResponses = [...document.querySelectorAll("model-response")]
                    .filter(el => !el.hasAttribute("data-aitest-old"));

                const newResponses = newModelResponses.length > 0 ? newModelResponses :
                    [...document.querySelectorAll("message-content")].filter(el => !el.hasAttribute("data-aitest-old"));

                if (newResponses.length > 0) {
                    const latestNewResponse = newResponses[newResponses.length - 1];
                    const text = latestNewResponse.innerText.trim();

                    const hasAnswerTag = /(?:JAVOB|ANSWER|ОТВЕТ)\s*[:=\-—]\s*[A-DА-Я]/i.test(text);

                    if (text && text === previousText) {
                        stable++;
                    } else {
                        previousText = text;
                        stable = 0;
                    }

                    // Javob chiqishi bilan DARHOL faqat harfni ajratib olamiz
                    if (text && (stable >= 2 || (hasAnswerTag && stable >= 1))) {
                        clearInterval(timer);
                        const cleanAnswer = extractCleanAnswer(text);
                        resolve(cleanAnswer);
                        return;
                    }
                }

                // 115 tsikl * 400ms = ~46 soniya maksimal kutish
                if (attempts >= 115) {
                    clearInterval(timer);
                    resolve(previousText ? extractCleanAnswer(previousText) : "Javob kelmadi (Internet sekin)");
                }
            }, 400);
        });
    } catch (error) {
        return "Xatolik: " + error.message;
    }
}
