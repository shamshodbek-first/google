
let isEnabled = false;
let isOverlayHidden = false;
let isShieldApplied = false;

chrome.storage.local.get("enabled", (data) => {
    isEnabled = data.enabled;
    if (isEnabled) activateShieldV14();
});

chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === "toggle") {
        isEnabled = msg.state;
        if (isEnabled) activateShieldV14();
        else location.reload();
    }
});

function activateShieldV14() {
    if (isShieldApplied) return; 
    isShieldApplied = true;
    createStealthControlBar();

    console.clear = () => {};
    Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
    Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });

    const stopEvent = (e) => {
        if (isEnabled) {
            e.stopImmediatePropagation();
            return false;
        }
    };

    ['blur', 'focusout', 'visibilitychange', 'mouseleave', 'mouseout', 'resize', 'contextmenu', 'copy', 'paste', 'cut', 'selectstart'].forEach(evt => {
        window.addEventListener(evt, stopEvent, true);
        document.addEventListener(evt, stopEvent, true);
    });

    window.addEventListener('keydown', (e) => {
        if (!isEnabled) return;

        if (e.altKey && (e.key.toLowerCase() === 's' || e.code === 'KeyS')) {
            e.stopImmediatePropagation(); e.preventDefault();
            captureAndSolve();
            return;
        }
        if (e.altKey && (e.key.toLowerCase() === 'd' || e.code === 'KeyD')) {
            e.stopImmediatePropagation(); e.preventDefault();
            toggleOverlay();
            return;
        }
        if (e.altKey && (e.key.toLowerCase() === 'x' || e.code === 'KeyX')) {
            e.stopImmediatePropagation(); e.preventDefault();
            closeAndCleanGemini();
            return;
        }

        const allowed = ['0','1','2','3','4','5','6','7','8','9','Enter','Backspace','Tab','Escape','Delete','ArrowLeft','ArrowRight','ArrowUp','ArrowDown','F1','F2','F3','F4','F5','F6','F7','F8','F9','F10','F11','F12'];
        
        if (allowed.includes(e.key) && !e.altKey && !e.ctrlKey && !e.metaKey) {
            return; 
        }

        e.stopImmediatePropagation();
        e.preventDefault();
    }, true);

    window.addEventListener('keyup', stopEvent, true);
    window.addEventListener('keypress', stopEvent, true);

    const p_nop = () => Promise.resolve();
    [Element.prototype, document, document.documentElement].forEach(obj => {
        ['requestFullscreen', 'webkitRequestFullscreen', 'mozRequestFullScreen', 'msRequestFullscreen'].forEach(m => {
            if (obj && obj[m]) obj[m] = p_nop;
        });
    });

    setInterval(() => {
        if (isEnabled && (document.fullscreenElement || document.webkitFullscreenElement)) {
            (document.exitFullscreen || document.webkitExitFullscreen || (()=>{}))();
        }
    }, 100);
}

function toggleOverlay() {
    isOverlayHidden = !isOverlayHidden;
    const el = document.getElementById("ai-stealth-final-v14");
    if (el) el.style.display = isOverlayHidden ? "none" : "block";
}

async function captureAndSolve() {
    if (!isEnabled) return;
    let overlay = document.getElementById("ai-stealth-final-v14");
    if (!overlay) {
        overlay = document.createElement("div");
        overlay.id = "ai-stealth-final-v14";
        overlay.style = "position:fixed; bottom:5px; left:5px; z-index:2147483647; padding:5px 8px; background:rgba(255,255,255,0.01); color:#888; border-radius:3px; font-size:10px; font-family:monospace; pointer-events:none; max-width:300px; max-height:100px; overflow:hidden;";
        document.body.appendChild(overlay);
    }
    overlay.innerText = "..";
    overlay.style.display = isOverlayHidden ? "none" : "block";
    
    chrome.runtime.sendMessage({ action: "capture" }, (response) => {
        if (response && response.answer) overlay.innerText = response.answer;
    });
}

function closeAndCleanGemini() {
    const el = document.getElementById("ai-stealth-final-v14");
    if (el) el.innerText = "";
    chrome.runtime.sendMessage({ action: "cleanup_gemini" });
}

function createStealthControlBar() {
    if (document.getElementById("ai-stealth-controls-v14")) return;

    const bar = document.createElement("div");
    bar.id = "ai-stealth-controls-v14";
    bar.style.cssText = `
        position: fixed;
        bottom: 2px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 2147483647;
        display: flex;
        gap: 5px;
        user-select: none;
        background: transparent;
    `;

    // 1. Solve (Rasmga olib yechish - Alt + S)
    const btnSolve = createStealthBtn("·", () => {
        captureAndSolve();
    });

    // 2. Toggle (Yashirish / Ko'rsatish - Alt + D)
    const btnToggle = createStealthBtn("·", () => {
        toggleOverlay();
    });

    // 3. Clean (Yopish va tozalash - Alt + X)
    const btnClean = createStealthBtn("·", () => {
        closeAndCleanGemini();
    });

    bar.appendChild(btnSolve);
    bar.appendChild(btnToggle);
    bar.appendChild(btnClean);

    (document.body || document.documentElement).appendChild(bar);
}

function createStealthBtn(dotChar, onClick) {
    const btn = document.createElement("div");
    btn.style.cssText = `
        width: 38px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        background: rgba(255, 255, 255, 0.001);
        color: rgba(140, 140, 140, 0.08);
        font-size: 16px;
        font-family: monospace;
        transition: color 0.15s, background 0.15s;
        border-radius: 3px;
    `;
    btn.innerText = dotChar;

    btn.addEventListener("mouseenter", () => {
        btn.style.color = "rgba(140, 140, 140, 0.4)";
        btn.style.background = "rgba(255, 255, 255, 0.05)";
    });

    btn.addEventListener("mouseleave", () => {
        btn.style.color = "rgba(140, 140, 140, 0.08)";
        btn.style.background = "rgba(255, 255, 255, 0.001)";
    });

    btn.addEventListener("click", (e) => {
        e.stopImmediatePropagation();
        e.preventDefault();
        onClick();
    });

    return btn;
}
